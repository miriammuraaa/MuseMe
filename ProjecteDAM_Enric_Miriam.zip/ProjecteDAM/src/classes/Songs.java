package classes;
import java.sql.*;
public class Songs {
	private int song_ID;
	private String name;
	private String duration;
	
public static void main(String[] args) {	
		
		
		Songs track= new Songs("Endless,Nameless","6:43");
		
		try {
		Connection myConnection = DriverManager.getConnection("jdbc:mysql://sql7.freesqldatabase.com:3306/sql7622470", "sql7622470", "gkREcgyY8t");
		
		Statement mystatement = myConnection.createStatement();
		
		
		
		mystatement.executeUpdate("INSERT INTO Songs (Name,Duration,FK_IDAlbum) VALUES ('"+track.getName()+"','"+track.getDuration()+"',(SELECT ID_Album FROM Album WHERE Name='Nevermind'))");
		
		System.out.println("Canço introduit correctament");

	
	} catch (SQLException e) {
			
		e.printStackTrace();
	}}

		
	public Songs(String name, String duration) {
		
		this.name=name;
		this.duration=duration;
		
	}

	public Songs() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	/**
	 * @return the song_ID
	 */
	public int getSong_ID() {
		return song_ID;
	}

	/**
	 * @param song_ID the song_ID to set
	 */
	public void setSong_ID(int song_ID) {
		this.song_ID = song_ID;
	}
	
	
	
}
